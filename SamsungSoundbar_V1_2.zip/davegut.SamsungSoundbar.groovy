/*	Samsung Soundbar using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md

===== Notification Sounds	=====
[title: "Bell 1", uri: "http://s3.amazonaws.com/smartapp-media/sonos/bell1.mp3", duration: "10"]
[title: "Dogs Barking", uri: "http://s3.amazonaws.com/smartapp-media/sonos/dogs.mp3", duration: "10"]
[title: "Fire Alarm", uri: "http://s3.amazonaws.com/smartapp-media/sonos/alarm.mp3", duration: "17"]
[title: "The mail has arrived",uri: "http://s3.amazonaws.com/smartapp-media/sonos/the+mail+has+arrived.mp3", duration: "1"]
[title: "A door opened", uri: "http://s3.amazonaws.com/smartapp-media/sonos/a+door+opened.mp3", duration: "1"]
[title: "There is motion", uri: "http://s3.amazonaws.com/smartapp-media/sonos/there+is+motion.mp3", duration: "1"]
[title: "Someone is arriving", uri: "http://s3.amazonaws.com/smartapp-media/sonos/someone+is+arriving.mp3", duration: "1"]
=====	Some working Streaming Stations =====
[title:"Cafe del Mar", uri:"https://streams.radio.co/se1a320b47/listen", duration: 0]
[title:"UT-KUTX", uri: "https://kut.streamguys1.com/kutx-web", duration: 0]
[title:"89.7 FM Perth", uri: "https://ice8.securenetsystems.net/897FM", duration: 0]
[title:"Euro1", uri:"https://streams.radio.co/se1a320b47/listen", duration: 0]
[title:"Easy Hits Florida", uri:"http://airspectrum.cdnstream1.com:8114/1648_128", duration: 0]
[title:"Austin Blues", uri:"http://158.69.131.71:8036/stream/1/", duration: 0]

===== Valid Track Entry Examples =====
[title:"Cafe del Mar", uri:"https://streams.radio.co/se1a320b47/listen", duration: 0]
[uri:"https://streams.radio.co/se1a320b47/listen", duration: 0]
[uri:"https://streams.radio.co/se1a320b47/listen"]
https://streams.radio.co/se1a320b47/listen
===== Method Descriptions =====
playText: sends the test to playTextAndResume for processing

playTextAndRestore / Resume: converts the text to an audio stream and sends the trackData to
associated playTextAnd(Resume/Restore) methods.

playTrack:  Plays the track immediately.  This track becomes the MASTER used in recoverying
from the playTrackAnd(Resume/Restore) methods.

playTrackAnd(Resume/Restore).  Sends the audio track to the play queue with a switch for
Resume.  If resume is true, the Master Track (see playTrack) will begin playing when the
queue empties.

Queue:  The queue is a firstIn/firstOut function that actually controls the play of Audio
Notifications.  Queue can hang.
	a.	kickStartQueue:  forces the queue to start again.  This is also scheduled to run every
		30 minutes to keep the queue clear.
	b.	clearQueue: Zeroes out the queue and associated states.
	c.	resumePlayer: When the queue is empty, the system will be reset to the MASTER TRACK,
		volume is set to the original volume, the input source is set to the one at the start
		of playing.  If play is set, the MASTER TRACK will play - so if you do not want this,
		use the playTrackAndRestore.

URI Presets.  There are 8 presets that can be used for quick play used for quick playing of
regular channels.  These also work well in dashboards using the capability PushableButton
push method.
	a.	Uri Preset Create: This creates a URI from the current Master URI.  To create:
		1.	Enter the track data into the Play Track function and wait for the uri to be
		playing.
		2.	Enter a number (1-8) and your name for the URI in the command box.
		3.	State variable urlPresetData contains a list of defined url's.  Remember to
			refresh your browser after adding a preset.
	b.	URI Preset Play:  When selected, it will play the preset and become the MASTER TRACK.


==============================================================================*/
import org.json.JSONObject
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.util.XmlSlurper
import groovy.util.XmlParser
def driverVer() { return "1.2" }

metadata {
	definition (name: "Samsung Soundbar",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Soundbar.groovy"
			   ){
		capability "Switch"
		capability "MediaInputSource"
		capability "AudioNotification"
		capability "AudioVolume"
		capability "MusicPlayer"
		attribute "currentUri", "string"
		capability "Refresh"
		capability "PushableButton"
		command "urlPresetCreate", [[name: "Url Preset Number", type: "NUMBER"],[name: "URL Preset Name", type: "STRING"]]
		command "urlPresetPlay", [[name: "Url Preset Number", type: "NUMBER"]]
		command "urlPresetDelete", [[name: "Url Preset Number", type: "NUMBER"]]
		command "kickStartQueue"
		command "clearQueue"
		command "setInputSource", [[
			name: "Soundbar Input",
			constraints: ["digital", "HDMI1", "bluetooth", "HDMI2", "wifi"],
			type: "ENUM"]]
		command "toggleInputSource"
	}
	preferences {
		input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
		if (stApiKey) {
			input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
		}
		if (stDeviceId) {
			input ("deviceIp", "string", title: "deviceIp")
			input ("volIncrement", "number", title: "Volume Up/Down Increment", defaultValue: 1)
			input ("pollInterval", "enum", title: "Poll Interval (minutes)",
				   options: ["1", "5", "10", "30"], defaultValue: "5")
			input ("useVoices", "bool",  title: "Use Voices RSS for TTS generation", defaultValue: false)
			if (useVoices) {
				def ttsLanguages = ["en-au":"English (Australia)","en-ca":"English (Canada)", "en-gb":"English (Great Britain)",
									"en-us":"English (United States)", "en-in":"English (India)","ca-es":"Catalan",
									"zh-cn":"Chinese (China)", "zh-hk":"Chinese (Hong Kong)","zh-tw":"Chinese (Taiwan)",
									"da-dk":"Danish", "nl-nl":"Dutch","fi-fi":"Finnish","fr-ca":"French (Canada)",
									"fr-fr":"French (France)","de-de":"German","it-it":"Italian","ja-jp":"Japanese",
									"ko-kr":"Korean","nb-no":"Norwegian","pl-pl":"Polish","pt-br":"Portuguese (Brazil)",
									"pt-pt":"Portuguese (Portugal)","ru-ru":"Russian","es-mx":"Spanish (Mexico)",
									"es-es":"Spanish (Spain)","sv-se":"Swedish (Sweden)"]
				input ("ttsApiKey", "string", title: "TTS Site Key", description: "From http://www.voicerss.org/registration.aspx")
				input ("ttsLang", "enum", title: "TTS Language", options: ttsLanguages, defaultValue: "en-us")
			}
			input ("infoLog", "bool",  
				   title: "Info logging", defaultValue: true)
			input ("debugLog", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
		}
	}
}

def installed() {
	sendEvent(name: "switch", value: "on")
	sendEvent(name: "volume", value: 0)
	sendEvent(name: "mute", value: "unmuted")
	sendEvent(name: "status", value: "stopped")
	sendEvent(name: "mediaInputSource", value: "wifi")
	state.urlPresetData = [:]
	runIn(1, updated)
}

def updated() {
	def commonStatus = commonUpdate()
	if (volIncrement == null || !volIncrement) {
		device.updateSetting("volIncrement", [type:"number", value: 1])
	}
	sendEvent(name: "numberOfButtons", value: "29")
	state.remove("playQueue")
	state.playingNotification = false
	state.playQueue = []
	clearQueue()
	state.triggered = false
	runEvery30Minutes(kickStartQueue)
	if (commonStatus.status == "OK") {
		logInfo("updated: ${commonStatus}")
	} else {
		logWarn("updated: ${commonStatus}")
	}
	deviceSetup()
}

//	===== capability "Switch" =====
def on() { setSwitch("on") }
def off() { setSwitch("off") }
def setSwitch(onOff) {
	def cmdData = [
		component: "main",
		capability: "switch",
		command: onOff,
		arguments: []]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setSwitch: [cmd: ${onOff}, ${cmdStatus}]")
}

//	===== capability "MediaInputSource" =====
def toggleInputSource() {
	if (state.supportedInputs) {
		def inputSources = state.supportedInputs
		def totalSources = inputSources.size()
		def currentSource = device.currentValue("mediaInputSource")
		def sourceNo = inputSources.indexOf(currentSource)
		def newSourceNo = sourceNo + 1
		if (newSourceNo == totalSources) { newSourceNo = 0 }
		def inputSource = inputSources[newSourceNo]
		setInputSource(inputSource)
	} else { logWarn("toggleInputSource: NOT SUPPORTED") }
}
def setInputSource(inputSource) {
	if (state.supportedInputs) {
		def inputSources = state.supportedInputs
		if (inputSources.contains(inputSource)) {
		def cmdData = [
			component: "main",
			capability: "mediaInputSource",
			command: "setInputSource",
			arguments: [inputSource]]
		def cmdStatus = deviceCommand(cmdData)
		logInfo("setInputSource: [cmd: ${inputSource}, ${cmdStatus}]")
		} else {
			logWarn("setInputSource: Invalid input source")
		}
	} else { logWarn("setInputSource: NOT SUPPORTED") } 
}

//	=====	capability "MusicPlayer" =====
def setLevel(level) { setVolume(level) }

//	===== Media Transport =====
def play() { 
	upnpPlay()
//	setMediaPlayback("play")
}
def pause() { 
	upnpPause()
//	setMediaPlayback("pause") 
}
def stop() { 
	upnpStop()
//	setMediaPlayback("stop") 
}
def setMediaPlayback(pbMode) {
	def cmdData = [
		component: "main",
		capability: "mediaPlayback",
		command: pbMode,
		arguments: []]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setMediaPlayback: [cmd: ${pbMode}, ${cmdStatus}]")
}

def mute() { setMute("muted") }
def unmute() { setMute("unmuted") }
def toggleMute() {
	def muteValue = "muted"
	if(device.currentValue("mute") == "muted") {
		muteValue = "unmuted"
	}
	setMute(muteValue)
}
def setMute(muteValue) {
	def cmdData = [
		component: "main",
		capability: "audioMute",
		command: "setMute",
		arguments: [muteValue]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setMute: [cmd: ${muteValue}, ${cmdStatus}]")
}

//	===== UPnP Media Transport Methods =====
def previousTrack() {
	sendUpnpCmd("AVTransport",
				"Previous",
				["InstanceID" :0])
}
def nextTrack() {
	sendUpnpCmd("AVTransport",
				"Next",
				["InstanceID" :0])
}
def setTrack(trackData) {
logTrace("setTrack: $trackData")
	def uri
	def title = "unknown"
	def duration = 0
	if (trackData.class == String) {
		if(trackData.startsWith("htt")) {
			uri = trackData
		} else {
			try{
				trackData = parseJson(trackData)
				uri = trackData.uri
				title = trackData.title
				duration = trackData.duration
			} catch (e) {
				logWarn("setTrack: [error: uri is not properly formatted]")
				return
			}
		}
	} else {
		uri = trackData.uri
		title = trackData.title
		duration = trackData.duration
	}

	def metadata = """<DIDL-Lite"""
	metadata += """ xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" """
	metadata += """xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/" """
	metadata += """xmlns:dc="http://purl.org/dc/elements/1.1/" """
	metadata += """xmlns:dlna="urn:schemas-dlna-org:metadata-1-0/">"""
	metadata += """<item>"""
	metadata += """<title>${title}</title>"""
	metadata += """<duration>${duration}</duration>"""
	metadata += """<upnp:class>object.item.audioItem</upnp:class>"""
	metadata += """<res>${uri}</res>"""
	metadata += """</item></DIDL-Lite>"""

	sendUpnpCmd("AVTransport",
				"SetAVTransportURI",
				 [InstanceID: 0,
				  CurrentURI: uri,
				  CurrentURIMetaData: metadata])
}
def restoreTrack(uri) {
	state.play = false
	setTrack(uri)
}
def resumeTrack(uri) {
	setTrack(uri)
}
//	playText(text) see AudioNotificaton playText
//	playTrack(trackUri) see AudioNotification playTrack

//	===== capability "AudioVolume" =====
def volumeUp() { 
	def curVol = device.currentValue("volume")
	def newVol = curVol + volIncrement.toInteger()
	setVolume(newVol)
}
def volumeDown() {
	def curVol = device.currentValue("volume")
	def newVol = curVol - volIncrement.toInteger()
	setVolume(newVol)
}
def setVolume(volume) {
	if (volume == null) { volume = device.currentValue("volume") }
	else if (volume < 0) { volume = 0 }
	else if (volume > 100) { volume = 100 }
	def cmdData = [
		component: "main",
		capability: "audioVolume",
		command: "setVolume",
		arguments: [volume]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setVolume: [cmd: ${volume}, ${cmdStatus}]")
}

//	===== Play Text Methods =====
def playText(text, volume = null) { playTextAndResume(text) }
def playTextAndRestore(text, volume = null) {
	logDebug("playTextAndRestore: [text: ${text}, Volume: ${volume}]")
	def trackData = convertToTrack(text)
	playTrackAndRestore(trackData, volume)
}
def playTextAndResume(text, volume = null) {
	logDebug("playTextAndResume: [text: ${text}, Volume: ${volume}]")
	def trackData = convertToTrack(text)
	playTrackAndResume(trackData, volume)
}
def convertToTrack(text) {
	def track
	if (!useVoices) {
		track = textToSpeech(text)
	} else {										//	Soundbar
		def uriText = URLEncoder.encode(text, "UTF-8").replaceAll(/\+/, "%20")
		uri = "http://api.voicerss.org/?" +
			"key=${ttsApiKey.trim()}" +
			"&f=48khz_16bit_mono" +
			"&c=MP3" +
			"&hl=${ttsLang}" +
			"&src=${uriText}"
		def duration = (1 + text.length() / 10).toInteger()
		track =  [uri: uri, name: "TTS", duration: duration]
	}
	return track
}

//	===== Play Track Methods =====
def playTrack(trackData, volume = null) {
	//	Immediate command.  Will stop all other playing, and empty the playQueue.
	logDebug("playTrack: [trackData: ${trackData}, volume: ${volume}]")
	try {
		duration = trackData.duration.toInteger()
		uri = trackData.uri
	} catch (e) {
		trackData = genTrackData(trackData, "playTrackAndRestore")
			duration = trackData.duration.toInteger()
			uri = trackData.uri
	}
		
	if (trackData != "error") {
		state.masterTrack = true
		state.play = true
		stop()
		if (volume == null) {
			volume = device.currentValue("volume")
		}
		setVolume(volume.toInteger())
		setTrack(trackData)
	}
}
def playTrackAndRestore(trackData, volume= null) {
	logDebug("playTrackAndRestore: [trackData: ${trackData}, Volume: ${volume}]")
logTrace("playTrackAndRestore: [trackData: ${trackData}, volume: ${volume}]")
	def duration
	def uri
	try {
		duration = trackData.duration.toInteger()
		uri = trackData.uri
	} catch (e) {
logTrace("playTrackAndRestore: alternate track data method")
		trackData = genTrackData(trackData, "playTrackAndRestore")
			duration = trackData.duration.toInteger()
			uri = trackData.uri
	}
		
	if (trackData != "error") {
		if (volume == null) {
			volume = device.currentValue("volume").toInteger()
		}
		def addQueueData = [uri: uri,
							duration: duration,
							volume: volume,
							resume: false]
		addToQueue(addQueueData)
	}
}
def playTrackAndResume(trackData, volume=null) {
	logDebug("playTrackAndResume: [trackData: ${trackData}, Volume: ${volume}]")
	try {
		duration = trackData.duration.toInteger()
		uri = trackData.uri
	} catch (e) {
		trackData = genTrackData(trackData, "playTrackAndRestore")
			duration = trackData.duration.toInteger()
			uri = trackData.uri
	}
		
	if (trackData != "error") {
		if (volume == null) {
			volume = device.currentValue("volume").toInteger()
		}
		def addQueueData = [uri: uri,
							duration: duration,
							volume: volume,
							resume: false]
		addToQueue(addQueueData)
	}
}
def genTrackData(trackData, meth) {
	if (trackData.class == String) {
		if (trackData.startsWith("http")) {
			trackData = """{duration:0,title:"${trackData}",uri:"${trackData}"}"""
		}
		try {
			trackData = trackData.replace("[","{").replaceAll("]","}")
			trackData = new JSONObject(trackData)
		} catch (error) {
			logWarn("genTrackData: [method: ${meth}, trackData: ${trackData}, errorCode: 101, error: trackData malformed]")
			return "error"
		}
		return trackData
	} else {
		logWarn("genTrackData: [method: ${meth}, trackData: ${trackData}, errorCode: 101, error: trackData malformed]")
		return "error"
	}
}

//	===== Custom Implemenation "PlayQueue" =====
def addToQueue(addData){
	logDebug("addToQueue: ${addData}")
	def playData = ["uri": addData.uri,
					"duration": addData.duration,
					"requestVolume": addData.volume]
	state.playQueue.add(playData)

	if (state.playingNotification == false) {
		state.playingNotification = true
		runIn(1, startPlayViaQueue, [data: addData])
	} else {
		runIn(30, kickStartQueue)
	}
}
def startPlayViaQueue(addData) {
	logDebug("startPlayViaQueue: ${addData}")
	if (state.playQueue.size() == 0) { return }
	state.resetData = [volume: device.currentValue("volume"),
					   inputSource: device.currentValue("inputSource"),
					   resume: addData.resume]
	runIn(1, playViaQueue)
}
def playViaQueue() {
	logDebug("playViaQueue: queueSize = ${state.playQueue.size()}")
	if (state.playQueue.size() == 0) {
		resumePlayer()
	} else {
		if (device.currentValue("status") != "stopped") {
			stop()
		}
		def playData = state.playQueue.get(0)
		state.play = true
		setVolume(playData.requestVolume.toInteger())

		sendUpnpCmd("AVTransport", "SetAVTransportURI",
					[InstanceID: 0, CurrentURI: playData.uri,
					 CurrentURIMetaData: ""])

		state.playQueue.remove(0)
		def duration = playData.duration.toInteger()
		if (duration > 0) {
			runIn(duration + 4, playViaQueue)
		}
		runIn(30, kickStartQueue)
	}
}
def resumePlayer() {
	if (state.playQueue.size() > 0) {
		playViaQueue()
	} else {
		state.playingNotification = false
		def resetData = state.resetData
		state.resetData = []
		logDebug("resumePlayer: resetData = ${resetData}")

		if (resetData.resume == true) { state.play = true } 
		else { state.play = falase }
		setVolume(resetData.volume.toInteger())
		if (resetData.inputSource != null) {
			setInputSource(respData.inputSource)
		}
		if (device.currentValue("status") != "stopped") {
			stop()
		}
		def trackData = parseJson(device.currentValue("trackData"))
		setTrack(trackData)
	}
}
def kickStartQueue() {
	logDebug("kickStartQueue: playQueue: ${state.playQueue}")
	if (state.playQueue.size() > 0) {
		playViaQueue()
	}
}
def clearQueue() {
	logDebug("clearQueue")
	state.playQueue = []
	state.playingNotification = false
	state.play = false
	state.masterTrack = false
}

//	===== UPnP Interface =====
def upnpPlay() {
	sendUpnpCmd("AVTransport",
				"Play",
				["InstanceID" :0,
				 "Speed": "1"])
}
def upnpPause() {
	sendUpnpCmd("AVTransport",
				"Pause",
				["InstanceID" :0])
}
def upnpStop() { 
	sendUpnpCmd("AVTransport",
				"Stop",
				["InstanceID" :0])
}
def getTransportInfo() {
	sendUpnpCmd("AVTransport",
				"GetTransportInfo",
				 [InstanceID: 0])
}
def getMediaInfo() {
	sendUpnpCmd("AVTransport",
				"GetMediaInfo",
				 [InstanceID: 0])
}

private sendUpnpCmd(type, action, body = []){
	def deviceIP = getDataValue("deviceIp")
	def host = "${deviceIp}:9197"
	def hubCmd = new hubitat.device.HubSoapAction(
		path:	"/upnp/control/${type}1",
		urn:	 "urn:schemas-upnp-org:service:${type}:1",
		action:  action,
		body:	body,
		headers: [Host: host, CONNECTION: "close"]
	)
	sendHubCommand(hubCmd)
}
def parse(resp) {
	resp = parseLanMessage(resp)
//	log.trace groovy.xml.XmlUtil.escapeXml(resp.body)
	def body = resp.xml.Body
	if (!body.size()) {
		logWarn("parse: No XML Body in resp: ${resp}")
	}
	else if (body.GetTransportInfoResponse.size()) { updatePlayStatus(body.GetTransportInfoResponse) }
	else if (body.GetMediaInfoResponse.size()) { parseMediaInfo(body.GetMediaInfoResponse) }
	else if (body.SetAVTransportURIResponse.size()) { parseAVTransport(body.SetAVTransportURIResponse) }
	else if (body.PlayResponse.size()) { runIn(2,getTransportInfo) }
	else if (body.PauseResponse.size()) { runIn(2,getTransportInfo) }
	else if (body.StopResponse.size()) { runIn(2,getTransportInfo) }
	else if (body.Fault.size()) { parseFault(body.Fault) }
	//	===== Fault Code =====
	else {
		logWarn("parse: [unhandledResponse: ${groovy.xml.XmlUtil.escapeXml(resp.body)}]")
	}
}

def parseAVTransport(data) {
	logDebug("parseAVTransport: [play: ${state.play}]")
	if (state.play) {
		state.play = false
		upnpPlay()
	}
	runIn(2, getMediaInfo)
}
def parseMediaInfo(data) {
	logDebug("parseMediaInfo: [masterTrack: ${state.masterTrack}, data: ${data}]")
	def currentUri =  data.CurrentURI.text()
	if (currentUri == "") { currentUri = "none" }
	sendEvent(name: "currentUri", value: currentUri)
	def logData = [currentUri: currentUri]
	if (state.masterTrack) {
		state.masterTrack = false
		def uriMetadata = groovy.xml.XmlUtil.escapeXml(data.CurrentURIMetaData.toString())
		uriMetadata = uriMetadata.toString().replaceAll("&lt;", "<").replaceAll("&gt;", ">")
		uriMetadata = uriMetadata.replaceAll("&quot;","\"")
		uriMetadata = new XmlSlurper().parseText(uriMetadata)
		def trackData = """{title: "${uriMetadata.item.title}", """ +
			"""uri: "${uri: currentUri}", duration: ${uriMetadata.item.duration}}"""
		trackData = new JSONObject(trackData)
		
		sendEvent(name: "trackDescription", value: trackData.title)
		sendEvent(name: "trackData", value: trackData)
		logData << [trackData: trackData]
		logData << [trackDescription: trackData.title]
	}
	logDebug("parseMediaInfo: ${logData}")
}
def updatePlayStatus(data) {
	def status = data.CurrentTransportState.text()
	def transStatus = device.currentValue("status")
	switch(status) {
		case "PLAYING":
			transStatus = "playing"
			break
		case "PAUSED_PLAYBACK":
			transStatus = "paused"
			break
		case "STOPPED":
			transStatus = "stopped"
			break
		case "TRANSITIONING":
			runIn(15,getTransportInfo)
			break
		case "NO_MEDIA_PRESENT": 
			transStatus = "stopped"
			logWarn("updatePlayStatus: [status: ${status}]")
			break
		default:
			logWarn("updatePlayStatus: [unhandled: ${status}]")
	}
	sendEvent(name: "status", value: transStatus)
}
def parseFault(data) {
	def faultData = data.detail.UPnPError.errorDescription.text()
	def code = data.faultstring.text()
	state.play = false
	state.masterTrack = false
	logWarn("parseFault: [errorDescription: ${code}, ${faultData}]")
}

//	===== Custom Implementation "UrlStreamPreset" =====
def urlPresetCreate(preset, name = "Not Set") {
	if (preset < 1 || preset > 8) {
		logWarn("urlPresetCreate: Preset Number out of range (1-8)!")
		return
	}
	def trackData = parseJson(device.currentValue("trackData").toString())
	def urlData = [:]
	urlData["title"] = name
	urlData["uri"] = trackData.uri
	urlData["duration"] = trackData.duration
	state.urlPresetData << ["${preset}":[urlData]]
	logDebug("urlPresetCreate: created preset ${preset}, data = ${urlData}")
}
def urlPresetPlay(preset) {
	if (preset < 1 || preset > 8) {
		logWarn("urlPresetPlay: Preset Number out of range (1-8)!")
		return
	} 
	def urlData = state.urlPresetData."${preset}"
	if (urlData == null || urlData == [:]) {
		logWarn("urlPresetPlay: Preset Not Set!")
	} else {
		playTrack(urlData[0])
		logDebug("urlPresetPlay: ${urlData}")
	}
}
def urlPresetDelete(preset) {
	def urlPresetData = state.urlPresetData
	if (preset < 1 || preset > 8) {
		logWarn("urlPresetDelete: Preset Number ${preset} out of range (1-8)!")
	} else if (urlPresetData."${preset}" == null || urlPresetData."${preset}" == [:]) {
		logWarn("urlPresetDelete: Preset Not Set!")
	} else {
		urlPresetData << ["${preset}":[]]
		logInfo("urlPresetDelete: [preset: ${preset}]")
	}
}

//	===== capability "PushableButton" =====
def push(pushed) {
	logDebug("push: [button: ${pushed}, trigger: ${state.triggered}]")
	if (pushed == null) {
		logWarn("push: pushed is null.  Input ignored")
		return
	}
	sendEvent(name: "pushed", value: pushed)
	pushed = pushed.toInteger()
	switch(pushed) {
		case 0 :
			if (state.triggered == true) {
				state.triggered = false
				logDebug("push: Trigger is NOT ARMED")
			} else {
				state.triggered = true
				logDebug("push: Trigger is ARMED")
				runIn(15, unTrigger)
			}
			break
		case 1 :		//	Preset 1
		case 2 :		//	Preset 2
		case 3 :		//	Preset 3
		case 4 :		//	Preset 4
		case 5 :		//	Preset 5
		case 6 :		//	Preset 6
		case 7 :		//	Preset 7
		case 8 :		//	Preset 8
			if (state.triggered == false) {
				urlPresetPlay(pushed)
			} else {
				urlPresetCreate(pushed)
				sendEvent(name: "Trigger", value: "notArmed")
			}
			break
		case 10: refresh(); break
		case 11: toggleInputSource(); break
		case 12: volumeUp(); break
		case 13: volumeDown(); break
		
		case 20: clearQueue(); break
		case 21: kickStartQueue(); break
		default:
			logWarn("${device.label}: Invalid Preset Number (must be 0 thru 29)!")
			break
	}
}
def unTrigger() { state.triggered = false }

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			if (data.reason == "deviceSetup") {
				deviceSetupParse(respData.components.main)
			}
			statusParse(respData.components.main)
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("distResp: ${respLog}")
	}
}
def deviceSetupParse(mainData) {
	if (mainData.mediaInputSource != null) {
		def supportedInputs =  mainData.mediaInputSource.supportedInputSources.value
		sendEvent(name: "supportedInputs", value: supportedInputs)	
		state.supportedInputs = supportedInputs
	} else {
		state.remove("supportedInputs")
	}
	if (setupData != [:]) {
		logInfo("deviceSetupParse: ${setupData}")
	}
	listAttributes(true)
}
def statusParse(mainData) {
	def onOff = mainData.switch.switch.value
	if (device.currentValue("switch") != onOff) {
		sendEvent(name: "switch", value: onOff)
	}
	
	def volume = mainData.audioVolume.volume.value.toInteger()
	sendEvent(name: "volume", value: volume)

	def mute = mainData.audioMute.mute.value
	sendEvent(name: "mute", value: mute)

	def status = mainData.mediaPlayback.playbackStatus.value
	sendEvent(name: "status", value: status)
	
	if (mainData.mediaInputSource != null) {
		def mediaInputSource = mainData.mediaInputSource.inputSource.value
		sendEvent(name: "mediaInputSource", value: mediaInputSource)
	}
	
	if (mainData.audioTrackData != null) {
		def trackData = mainData.audioTrackData.audioTrackData.value
		sendEvent(name: "trackData", value: trackData)
	}

	if (simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Library Integration =====
#include davegut.Logging
#include davegut.ST-Communications
#include davegut.ST-Common
def simulate() { return false }
//#include davegut.Samsung-Soundbar-Sim
