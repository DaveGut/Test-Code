metadata {
	definition (name: "Range-Oven Design Docs",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}

//	I use methods below to describe different elements in the design. 
	
//	===== Design Definition =====
def componentLists() {
	def stComponents = [[
		id:"main", label:"Range", 
		capabilities:[
			[id:"ocf", version:1], 
			[id:"execute", version:1], 
			[id:"refresh", version:1], 
			[id:"remoteControlStatus", version:1], 
			[id:"ovenSetpoint", version:1], 
			[id:"ovenMode", version:1], 
			[id:"ovenOperatingState", version:1], 
			[id:"temperatureMeasurement", version:1], 
			[id:"samsungce.driverVersion", version:1], 
			[id:"samsungce.kitchenDeviceIdentification", version:1], 
			[id:"samsungce.kitchenDeviceDefaults", version:1], 
			[id:"samsungce.doorState", version:1], 
			[id:"samsungce.customRecipe", version:1], 
			[id:"samsungce.ovenMode", version:1], 
			[id:"samsungce.ovenOperatingState", version:1], 
			[id:"samsungce.meatProbe", version:1], 
			[id:"samsungce.lamp", version:1], 
			[id:"samsungce.kitchenModeSpecification", version:1], 
			[id:"samsungce.kidsLock", version:1], 
			[id:"custom.cooktopOperatingState", version:1], 
			[id:"custom.disabledCapabilities", version:1]], 
		categories:[[name:"Range", categoryType:"manufacturer"]]], 
	[
		id:"cavity-01", label:"1", 
		capabilities:[
			[id:"ovenSetpoint", version:1], 
			[id:"ovenMode", version:1], 
			[id:"ovenOperatingState", version:1], 
			[id:"temperatureMeasurement", version:1], 
			[id:"samsungce.ovenMode", version:1], 
			[id:"samsungce.ovenOperatingState", version:1], 
			[id:"samsungce.kitchenDeviceDefaults", version:1], 
			[id:"custom.ovenCavityStatus", version:1], 
			[id:"custom.disabledCapabilities", version:1]], 
		categories:[[name:"Other", categoryType:"manufacturer"]]]
	]
}

def disabledCapabilities() {
	//	For each component, not all capabilities are implemented in the code.
	//	Below defines the not-implemented capabilities for each component.
	def mainDesignDisabled = [               
		"ocf", "execute", "custom.disabledCapabilities", "samsungce.driverVersion",
		"samsungce.kitchenDeviceIdentification", "samsungce.kitchenDeviceDefaults",
		"samsungce.customRecipe", "samsungce.kitchenModeSpecification"
	]
	
	def cavityDesignDisabled = [
		"custom.disabledCapabilities", "samsungce.kitchenDeviceDefaults"]
	
/* MODEL Disabled Capabilities
Additionally, each model capability has a unique list of "disabledCapabilities" defined in the status return from the device.  These are filtered out during configuration to make an array of enabledCapabilities which are used to filter out not-avaiable commands.
*/
}

def capabilityPrecedence() {
/*
Since capabilities duplicate commands and attributes in many cases and also duplicate functionality, execution is set up on a priority basis.  When executing a command, I go through the enabled capability list and choose the "newest" capability that is enabled to implement the Hubitat function.
*	samsungce Capabilities (i.e., samsungce.ovenMode) have highest priority
*	custom Capabilities are next.
*	standard (SmartThings) capabilities (active and deprecated).
*/
}

//	===== Standard HubiThings Replica interfaces =====
/*
The following methods interface directly to the Application for data and control.  There are standard commands and then some custom commands I developed.  The custom commands are developed since the HubiThings Replica interface doesn't support some issues in the Samsung devices.  Examples:
*	Multiple capabilities reporting the same attribute with different values.
*	No support for child devices (yet)
*/

Map getReplicaCommands() {
/*
Definition: replica command.  This is a device method that receives data from the application for device processing.

This method loads the replicaCommands into device's Data.  The app then accesses this data when creating the rules using the app interface.  See setReplicaRules below.

when needing to send data to the command.  Data is then sent to the device's method.  The method in the driver is a good example of a properly formated command.

Note:  For the Samsung Appliance Series, the method will always be the same.
*/
}

Map getReplicaTriggers() {
/*
Defintion: replica trigger.  This is a device command that triggers actions to the SmartThings device through the standard replica interface.

This method loads the replicaTriggers into the device's data. The app then accesses this data when creating the rules using the app interface.  See setReplicaRules below.

Note:  For the Samsung Appliance Series, the method will always be the same.
*/
}

String setReplicaRules() {
/*
Definition: Replica rules are used by the app to determine how to handle certain events.

This data is stored in the device's Data and accessed by the application to determine how to react to triggers and handle data from SmartThings.

This section in the driver is a template loaded during the Configure command.  The device's rules data is updated by the app through the applications "Configure HubiThings Rules" interface.

Warning:  Modifying rules in the application does not update this method.  Subsequent running of "Configure" will overwrite the rules Data.

Note:  For the Samsung Appliance Series, the method will always be the same.
*/
	
	
	
	
	
	
	def rules = """{"version":1,"components":[
{"trigger":{"type":"attribute","properties":{"value":{"title":"HealthState","type":"string"}},"additionalProperties":false,"required":["value"],"capability":"healthCheck","attribute":"healthStatus","label":"attribute: healthStatus.*"},"command":{"name":"setHealthStatusValue","label":"command: setHealthStatusValue(healthStatus*)","type":"command","parameters":[{"name":"healthStatus*","type":"ENUM"}]},"type":"smartTrigger","mute":true},
{"trigger":{"name":"refresh","label":"command: refresh()","type":"command"},"command":{"name":"refresh","type":"command","capability":"refresh","label":"command: refresh()"},"type":"hubitatTrigger"},
{"trigger":{"name":"deviceRefresh","label":"command: deviceRefresh()","type":"command"},"command":{"name":"refresh","type":"command","capability":"refresh","label":"command: refresh()"},"type":"hubitatTrigger"}]}"""

	updateDataValue("rules", rules)
}

void replicaStatus(def parent=null, Map status=null) {
/*
Receives SmartThings device status data from application.
Called by:
*	Application on a periodic basis.
*	Device Triggered REFRESH Command.
Dat used by methods:
*	checkCapabilities during configuration
*	refreshAttributes otherwise
*/
}

void replicaHealth(def parent=null, Map health=null) {
//	Return of Health status from SmartThings
}

def setHealthStatusValue(value) {    
//	Receive data and update health status from application.
//	Note:  seems redundant from the above, but I have not thoroughly investigated yet.
}

void replicaEvent(def parent=null, Map event=null) {
/*
called by: Application when an event (or status message) is received from device
Data used by parent and child devices parseEvent
*/
}

private def sendCommand(String name, def value=null, String unit=null, data=[:]) {
/*
Normal method to interface to Replica.
Note:  For the Samsung Appliance Series, this method is only used for deviceRefresh and refresh.
    parent?.deviceTriggerHandler(device, [name:name, value:value, unit:unit, data:data, now:now])
*/
}

//	===== Custom Hubithings Replica Interfaces =====
//	Do to no support for child components in Replica, I have created methods that bypass the rules-based application interface.  The below command implements that interface:

def sendRawCommand(component, capability, command, arguments = []) {
/*
Self explanatory flow below.

RemoteControl: commands to the device are disabled if remoteControlEnabled is false. Users have explained to me that the actual device requires enabling the remote control before sending the device.  Since the application hides the response message failure from the device, I can not automatically parse this data.

THIS IS AN AREA TO TEST if my base assumption is incorrect.
*/
	if (device.currentValue("remoteControlEnabled")) {
		parent.setSmartDeviceCommand(deviceId, component, capability, command, arguments)
	} else {
	}
}

def deviceRefresh() {
/*	Some attributes in smartThings do NOT automatically update when changed.  A device refresh has to be
sent to force the update.  The Application has a special command to complete this chain and the attribute is then return. 
The method Refresh also runs this command to assure the latest data is available at the refresh,
*/
}

def capabilityCheck() {
/*
On many commands, I check the driver-generated state.deviceCapabilities prior to executing a command. Each Samsung device model has a separate set of overlapping capabilities AND a list of disabled capabilities.  If the design capability is on the "disabledCapabilities" list from the device's status message, then I will not execute that capability.

Note: state.deviceCapabilities is generated through the Configure command available on the interface or called through savePreferences.  The capabiblities are the remains of
	Total capabilities from the device data: definition
	Less capabilities from method designDisables
	Less capabilities from status {componentName}.disabledCapabilities
			(i.e., main.disabledCapabilities)

For devices with multiple capabilities, I will start checking with the samsungce.CAPABILITY, then custom.CAPABILITY, then CAPABILITY to determine which (if any) will be sent to the device.
*/
}

//	===== Example Return Data from SmartThings (provided by users)
/*
DEFINITION: [
	deviceId:b440aa23-9f34-bfb4-eef2-xxxxxxxxxxx, 
	name:[Range] Samsung, label:Range, 
	manufacturerName:Samsung Electronics, presentationId:DA-KS-RANGE-0101X, 
	deviceManufacturerCode:Samsung Electronics, locationId:55d80aa6-11a6-4456-9aed-xxxxxxxxx, 
	roomId:564192d9-95ba-4518-8577-xxxxxxx, 
	deviceTypeName:Samsung OCF Range, 
	components:[
		[
			id:main, label:Range, 
			capabilities:[
				[id:ocf, version:1], 
				[id:execute, version:1], 
				[id:refresh, version:1], 
				[id:remoteControlStatus, version:1], 
				[id:ovenSetpoint, version:1], 
				[id:ovenMode, version:1], 
				[id:ovenOperatingState, version:1], 
				[id:temperatureMeasurement, version:1], 
				[id:samsungce.driverVersion, version:1], 
				[id:samsungce.kitchenDeviceIdentification, version:1], 
				[id:samsungce.kitchenDeviceDefaults, version:1], 
				[id:samsungce.doorState, version:1], 
				[id:samsungce.customRecipe, version:1], 
				[id:samsungce.ovenMode, version:1], 
				[id:samsungce.ovenOperatingState, version:1], 
				[id:samsungce.meatProbe, version:1], 
				[id:samsungce.lamp, version:1], 
				[id:samsungce.kitchenModeSpecification, version:1], 
				[id:samsungce.kidsLock, version:1], 
				[id:custom.cooktopOperatingState, version:1], 
				[id:custom.disabledCapabilities, version:1]], 
			categories:[[name:Range, categoryType:manufacturer]]], 
		[
			id:cavity-01, label:1, 
			capabilities:[
				[id:ovenSetpoint, version:1], 
				[id:ovenMode, version:1], 
				[id:ovenOperatingState, version:1], 
				[id:temperatureMeasurement, version:1], 
				[id:samsungce.ovenMode, version:1], 
				[id:samsungce.ovenOperatingState, version:1], 
				[id:samsungce.kitchenDeviceDefaults, version:1], 
				[id:custom.ovenCavityStatus, version:1], 
				[id:custom.disabledCapabilities, version:1]], 
			categories:[[name:Other, categoryType:manufacturer]]]], 
	createTime:2020-11-29T02:34:41Z, 
	profile:[id:00eef220-8a5d-3f6a-be53-xxxxxxx], 
	ocf:[ocfDeviceType:oic.d.range, name:[Range] Samsung, specVersion:core.1.1.0, verticalDomainSpecVersion:1.2.1, 
		 manufacturerName:Samsung Electronics, modelNumber:TP2X_DA-KS-RANGE-0101X|40433941|5001011E03141101020000000000000, 
		 platformVersion:DAWIT 2.0, platformOS:TizenRT 1.0 + IPv6, hwVersion:MediaTek, firmwareVersion:A-RG-WW-TP2-21-COMM_40210802, 
		 vendorId:DA-KS-RANGE-0101X, vendorResourceClientServerVersion:MediaTek Release 2.210709.1, lastSignupTime:2022-02-06T21:41:38.344027Z], 
	type:OCF, 
	restrictionTier:0, 
	allowed:[]]]

STATUS: [
	components:[
		cavity-01:[
			ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2020-11-29T02:35:20.254Z]], 
			temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2020-11-29T02:35:20.290Z]], 
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.945Z, timestamp:2022-04-26T16:19:02.955Z], 
				operatingState:[value:ready, timestamp:2021-01-16T07:47:02.811Z], 
				progress:[value:1, timestamp:2021-01-16T07:47:02.811Z], 
				ovenJobState:[value:ready, timestamp:2021-01-16T07:47:02.811Z], 
				operationTime:[value:00:00:00, timestamp:2021-01-16T07:47:02.811Z]], 
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:null], defaultOvenMode:[value:ConvectionBake, timestamp:2021-07-06T20:56:23.566Z], defaultOvenSetpoint:[value:350, timestamp:2021-07-06T20:56:23.610Z]], 
			custom.ovenCavityStatus:[ovenCavityStatus:[value:off, timestamp:2020-11-29T02:35:20.385Z]], 
			ovenMode:[
				supportedOvenModes:[value:[Others], timestamp:2021-07-26T05:01:09.707Z], 
				ovenMode:[value:Others, timestamp:2021-07-26T04:43:08.029Z]], 
			ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.945Z, timestamp:2022-04-26T16:19:02.955Z],
				machineState:[value:ready, timestamp:2020-11-29T02:35:20.495Z], 
				progress:[value:1, unit:%, timestamp:2021-01-16T07:47:02.811Z], 
				supportedMachineStates:[value:null, timestamp:2020-11-29T02:43:38.329Z], 
				ovenJobState:[value:ready, timestamp:2020-11-29T02:35:20.589Z], 
				operationTime:[value:0, timestamp:2021-01-16T07:47:02.811Z]], 
			samsungce.ovenMode:[
				supportedOvenModes:[value:[SteamClean, SelfClean, NoOperation], timestamp:2021-07-26T05:01:09.707Z], 
				ovenMode:[value:NoOperation, timestamp:2021-07-26T04:43:08.029Z]]], 
		main:[
			ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2022-04-19T22:54:43.792Z]], 
			samsungce.meatProbe:[
				temperatureSetpoint:[value:0, unit:F, timestamp:2021-07-05T23:01:20.610Z],
				temperature:[value:0, unit:F, timestamp:2021-11-06T21:59:15.685Z], 
				satus:[value:disconnected, timestamp:2021-01-16T07:47:02.729Z]], 
			refresh:[:], 
			samsungce.doorState:[doorState:[value:closed, timestamp:2022-04-19T22:54:42.948Z]], 
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:3600, timestamp:2021-01-16T07:47:02.729Z], defaultOvenMode:[value:ConvectionBake, timestamp:2021-07-26T04:43:08.166Z], 
				defaultOvenSetpoint:[value:350, timestamp:2021-01-16T07:47:02.729Z]], 
			execute:[], 
			ocf:[], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-02-28T01:53:04.641Z]], 
			samsungce.customRecipe:[:], 
			samsungce.kitchenDeviceIdentification:[], 
			samsungce.kitchenModeSpecification:[],
			custom.cooktopOperatingState:[
				supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-11-05T02:59:11.253Z], 
				cooktopOperatingState:[value:ready, timestamp:2022-04-26T21:44:25.086Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[], timestamp:2021-07-05T01:15:09.933Z]], 
			samsungce.driverVersion:[versionNumber:[value:21042801, timestamp:2021-11-05T12:16:33.903Z]], 
			temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2022-04-19T22:54:43.792Z]], 
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.917Z, timestamp:2022-04-26T16:19:02.927Z], 
										  operatingState:[value:ready, timestamp:2022-04-19T22:54:43.617Z], 
										  progress:[value:1, timestamp:2021-01-16T07:47:01.589Z], 
										  ovenJobState:[value:ready, timestamp:2022-04-19T22:54:43.542Z], 
										  operationTime:[value:00:00:00, timestamp:2022-02-26T03:52:38.958Z]], 
			ovenMode:[
				supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, warming, Others, Dehydrate], timestamp:2021-11-12T02:59:11.564Z], 
					  ovenMode:[value:Others, timestamp:2022-04-19T22:54:43.795Z]], 
			ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.917Z, timestamp:2022-04-26T16:19:02.927Z], 
								machineState:[value:ready, timestamp:2022-04-19T22:54:43.617Z], 
								progress:[value:1, unit:%, timestamp:2021-11-06T21:59:01.515Z], 
								supportedMachineStates:[value:null, timestamp:2020-11-29T02:39:28.212Z], 
								ovenJobState:[value:ready, timestamp:2022-04-19T22:54:43.542Z], 
								operationTime:[value:0, timestamp:2022-02-26T03:52:38.958Z]], 
			samsungce.ovenMode:[
				supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, KeepWarm, BreadProof, Dehydrate, AirFryer], timestamp:2021-11-12T02:59:11.564Z], 
								ovenMode:[value:NoOperation, timestamp:2022-04-19T22:54:43.795Z]], 
			samsungce.lamp:[
				brightnessLevel:[value:off, timestamp:2022-04-19T22:54:43.120Z], 
				supportedBrightnessLevel:[value:[off, high], timestamp:2021-07-05T01:15:09.933Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-04-17T15:45:36.776Z]]]]]]
*/
