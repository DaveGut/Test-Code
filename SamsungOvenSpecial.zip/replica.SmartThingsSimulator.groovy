library (
	name: "SmartThingsSimulator",
	namespace: "replica",
	author: "Dave Gutheinz",
	description: "ST Replica Simulator",
	category: "utilities",
	documentationLink: ""
)
//ovenCavityStatus
def simulateSmartDeviceDescription(String deviceId) {
	Map description = [
	name:"[Range] Samsung", 
	label:"Range", 
	deviceId:"3047d02b-c0aa-48be-ae09-9d0f6afee091",
	components:[
		[
			id:"main", label:"Range", 
			capabilities:[
				[id:"ocf", version:1], 
				[id:"execute", version:1], 
				[id:"refresh", version:1], 
				[id:"remoteControlStatus", version:1], 
				[id:"ovenSetpoint", version:1], 
				[id:"ovenMode", version:1], 
				[id:"ovenOperatingState", version:1], 
				[id:"temperatureMeasurement", version:1], 
				[id:"samsungce.driverVersion", version:1], 
				[id:"samsungce.kitchenDeviceIdentification", version:1], 
				[id:"samsungce.kitchenDeviceDefaults", version:1], 
				[id:"samsungce.doorState", version:1], 
				[id:"samsungce.customRecipe", version:1], 
				[id:"samsungce.ovenMode", version:1], 
				[id:"samsungce.ovenOperatingState", version:1], 
				[id:"samsungce.meatProbe", version:1], 
				[id:"samsungce.lamp", version:1], 
				[id:"samsungce.kitchenModeSpecification", version:1], 
				[id:"samsungce.kidsLock", version:1], 
				[id:"custom.cooktopOperatingState", version:1], 
				[id:"custom.disabledCapabilities", version:1]], 
			categories:[[name:"Range", categoryType:"manufacturer"]]], 
		[
			id:"cavity-01", label:"1", 
			capabilities:[
				[id:"ovenSetpoint", version:1], 
				[id:"ovenMode", version:1], 
				[id:"ovenOperatingState", version:1], 
				[id:"temperatureMeasurement", version:1], 
				[id:"samsungce.ovenMode", version:1], 
				[id:"samsungce.ovenOperatingState", version:1], 
				[id:"samsungce.kitchenDeviceDefaults", version:1], 
				[id:"custom.ovenCavityStatus", version:1], 
				[id:"custom.disabledCapabilities", version:1]], 
			categories:[[name:"Other", categoryType:"manufacturer"]]]
	]
	]

	getReplicaDevices(deviceId)?.each { replicaDevice -> smartDescriptionHandler(replicaDevice, description); }
	description = null
}

def simulateSmartDeviceStatus(String deviceId) {
	Map status = [
	components:[
		"cavity-01":[
			ovenSetpoint:[
				ovenSetpoint:[value:325]],
			temperatureMeasurement:[
				temperature:[value:325, unit:"F"]],
			ovenMode:[
				supportedOvenModes:[value:["Bake", "ConvectionBake", "Others"]], 
				ovenMode:[value:"Bake"]],
			ovenOperatingState:[
				completionTime:[value:"2022-04-12T20:03:35.698Z"],
				machineState:[value:"running"],
				progress:[value:5, unit:"%"], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:"cooking"],
				operationTime:[value:3600]],
			"custom.ovenCavityStatus":[
				ovenCavityStatus:[value:"on"]],
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:null]],
			"samsungce.ovenMode":[
				supportedOvenModes:[value:["Bake", "ConvectionBake", "SteamClean", "SelfClean", "NoOperation"]], 
				ovenMode:[value:"Bake"]],
			"samsungce.ovenOperatingState":[
				completionTime:[value:"2022-04-12T20:03:35.698Z"],
				operatingState:[value:"running"],	
				progress:[value:5], 
				ovenJobState:[value:"cooking"],
				operationTime:[value:"01:00:00"]],
		],
		main:[
			ovenSetpoint:[
				ovenSetpoint:[value:"325"]],
			temperatureMeasurement:[
				temperature:[value:"325", unit:"F"]],
			ovenMode:[
				supportedOvenModes:[value:["Broil", "ConvectionBake", "ConvectionRoast"]],
				supportedOvenModes:[value:["Bake", "Broil", "ConvectionBake", "ConvectionRoast", "KeepWarm", "BreadProof", "Dehydrate"]], 
				ovenMode:[value:"ConvectionBake"]],
			ovenOperatingState:[
				completionTime:[value:"2022-04-12T19:55:34.605Z"], 
				machineState:[value:"running"], 
				progress:[value:6, unit:"%"], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:"cooking"], 
				operationTime:[value:3120]],
			"samsungce.kidsLock":[
				lockState:[value:"unlocked"]],
			"samsungce.lamp":[
				brightnessLevel:[value:"off"], 
				supportedBrightnessLevel:[value:["off", "high"]]],
			refresh:[:],
			remoteControlStatus:[
				remoteControlEnabled:[value:true]],
			"samsungce.doorState":[
				doorState:[value:"closed"]],
			"custom.cooktopOperatingState":[
				supportedCooktopOperatingState:[value:["BURNBABYBURN", "run", "ready"]], 
				cooktopOperatingState:[value:"ready"]],
			"samsungce.meatProbe":[
				temperatureSetpoint:[value:0, unit:"F"],
				temperature:[value:0, unit:"F"],
				status:[value:"connected"]],
			"samsungce.kitchenDeviceDefaults":[:],
			execute:[:],
			ocf:[:],
			"samsungce.customRecipe":[:], 
			"samsungce.kitchenDeviceIdentification":[:],
			"samsungce.kitchenModeSpecification":[:],
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:null]],
			"samsungce.driverVersion":[:],
			"samsungce.ovenMode":[
				supportedOvenModes:[value:["Bake", "Broil", "ConvectionBake", "ConvectionRoast", "KeepWarm", "BreadProof", "Dehydrate", "AirFryer"]], 
				ovenMode:[value:"ConvectionBake"]],
			"samsungce.ovenOperatingState":[
				completionTime:[value:"2022-04-12T19:55:34.605Z"], 
				operatingState:[value:"running"], 
				progress:[value:6], 
				ovenJobState:[value:"cooking"], 
				operationTime:[value:"00:52:00"]]
		]
	]]

	getReplicaDevices(deviceId)?.each { replicaDevice -> smartStatusHandler(replicaDevice, deviceId, status); }
	status = null
}


/*	===== HubiThings Replica App Changes =====
The below changes work with both live and development devices.
Issue Solved: Samsung appliances implement the capabilities based on model.
My method:	Appliance driver that is model independent using a superset of commands and attributes in the definition. 
1.	Replica Commands and Triggers.  Develop based on the superset of capabilities.
2.	Device Commands.  Normal except that where two capabilities handle the same function, design a single command for both with a priority for the samsungce.CAPABILITIES (these are the later ones for the more capable devices).
3.	Device attributes: For capabilities handling the same (essential) state, combine the attributes into a single attribute to absolutely avoid user confusion on similar states.
4.	deviceConfigure.  This new function will use the Description data and the Status data from the app to generate the deviceCapabilities list.
	1.	status.disabledCapabilities (if it esists) will filter out the description capabilities not used in the device.

//	===== new code =====
def developer() { return true }
//	Remove "//" from below.  library catches the # as live code.
//#include replica.SmartThingsSimulator
//	===== end new code =====

Map getSmartDeviceDescription(String deviceId) {
//	===== new code =====
	if (developer() == true && getReplicaDevices(deviceId)[0].toString().contains("develop")) {
		simulateSmartDeviceDescription(deviceId)
	} else {
//	===== end new code =====
	    logDebug "${app.getLabel()} executing 'getSmartDeviceDescription($deviceId)'"
    	Map response = [statusCode:iHttpError]
		Map data = [ uri: sURI, path: "/devices/${deviceId}", deviceId: deviceId, method: "getSmartDeviceDescription" ]
		response.statusCode = asyncHttpGet("asyncHttpGetCallback", data).statusCode
		return response
//	===== new code =====
	}
//	===== end new code =====
}

Map getSmartDeviceStatus(String deviceId) {
//	===== new code =====
	if (developer() == true && getReplicaDevices(deviceId)[0].toString().contains("develop")) {
		simulateSmartDeviceStatus(deviceId)
	} else {
//	===== end new code =====
	    logDebug "${app.getLabel()} executing 'getSmartDeviceStatus($deviceId)'"
	    Map response = [statusCode:iHttpError]
		Map data = [ uri: sURI, path: "/devices/${deviceId}/status", deviceId: deviceId, method: "getSmartDeviceStatus" ]
		response.statusCode = asyncHttpGet("asyncHttpGetCallback", data).statusCode
	    return response
//	===== new code =====
	}
//	===== end new code =====
}

*/