/*	Sengled Device Driver Series

		Copyright Dave Gutheinz

License Information:  https://github.com/DaveGut/HubitatActive/blob/master/sengledDevices/License.md

08.31.21	New release.  Provides for Color and Mono bulbs only.
===================================================================================================*/
def driverVer() { return "1.0.0" }
def type() { return "Master" }

metadata {
	definition (name: "Sengled Wifi ${type()}",
				namespace: "davegut",
				author: "Dave Gutheinz",
				importUrl: ""
			   ) {
		command "connect"
		command "addDevices"
		attribute "connected", "string"
		attribute "commsError", "bool"
//		capability "refresh"
	}
	preferences {
		input ("userName", "string",
			   title: "Sengled User Name",
			   defaultValue: null)
		input ("userPwd", "password",
			   title: "Sengled Password",
			   defaultValue: null)
		input ("updateCloudData", "bool", 
			   title: "Login and update cloud data.", 
			   defaultValue: false)
//		input ("addDevices", "bool", 
//			   title: "Add New Child devices", 
//			   defaultValue: false)
		input ("debug", "bool",
			   title: "30 minutes of debug logging", 
			   defaultValue: false)
		input ("descriptionText", "bool", 
			   title: "Enable description text logging", 
			   defaultValue: true)
	}
}

def installed() {
	def message = "Installing Sengled WiFi Master Driver"
	updateDataValue("driverVersion", driverVer())
	state.errorCount = 0
	sendEvent(name: "commsError", value: false)
	runIn(2, updated)
}

def updated() {
	logInfo("updated: Updating ${type()} preferences and settings.")
	def msg = "updated:"
	unschedule()
	clearCommsError()
	if (debug) { runIn(1800, debugOff) }
	msg += "\n\tDebug Logging = ${debug}."
	msg += "\n\tDescription Text = ${descriptionText}."
	logInfo(msg)

	//	Check data and get token and server data
	def serverConnect = false
	if (!getDataValue("token")) {
		state.SERVER_DATA = "Sengled token and addresses not set!"
		logWarn("updated: Sengled token and addresses not set!")
		serverConnect = true
	} else if (updateCloudData == true) {
		state.remove("SERVER_DATA")
		serverConnect = true
	}
	if (userName == null || userPwd == null) {
		serverConnect = false
		state.USER_DATA = "Username and/or Passsword not set!"
		logWarn("updated: Username and/or Passsword not set!")
	} else {
		state.remove("USER_DATA")
	}
	if (serverConnect == true) {
		logInfo("getting Sengled token and addresses")
		def tokenInfo = getToken()
		logInfo("updated(getToken): ${tokenInfo}")
		if (tokenInfo != "ERROR") {
			state.remove("TOKEN")
			def addressInfo = getAddresses()
			logInfo("updated (getAddresses): ${addressInfo}")
			if (addressInfo != "ERROR") {
				state.remove("ADDRESSES")
			} else {
				state.ADDRESSES = "DEVICE MAY NOT WORK.  Error getting addresses."
			}
		} else {
			state.TOKEN = "DEVICE MAY NOT WORK.  Errog getting token."
		}
		device.updateSetting("updateCloudData", [type:"bool", value: false])
	}
	//	Connect to server
	if (userName != null && userPwd != null && getDataValue("mqttAddr")) {
		connect()
	}
}

//	===== Server Data Methods=====
def getToken() {
	def uri = "https://life2.cloud.sengled.com/user/app/customer/v2/AuthenCross.json"
	def body = ["uuid": "xxx", "user": userName, "pwd": userPwd,
				"osType": "android", "productCode": "life", "appCode": "life"]
	def headers = ["Content-Type": "application/json"]
	def tokenInfo = "ERROR"
	def data = postJson(uri, headers, body)
	if (data.ret == 0) {
		def settingsUpdate = [:]
		updateDataValue("token", "${data.jsessionId}")
		settingsUpdate["token"] = data.jsessionId
		updateDataValue("customerId", "${data.customerId}")
		settingsUpdate["customerId"] = data.customerId
		tokenInfo = "Login Success. Settings = ${settingsUpdate}."
	} else {
		logWarn("getToken: Login Failure.  Server returned an error.")
	}
	return tokenInfo
}

def getAddresses() {
	def addressInfo = "ERROR"
	def uri = "https://life2.cloud.sengled.com/life2/server/getServerInfo.json"
	def body = []
	def headers = ["Cookie" : "JSESSIONID=${getDataValue("token")}"]

	def data = postJson(uri, headers, body)
	if (data.messageCode == "200") {
		def settingsUpdate = [:]
		updateDataValue("appServerAddr", "${data.appServerAddr}")
		settingsUpdate["appServerAddr"] = data.appServerAddr
		updateDataValue("mqttAddr", "${data.inceptionAddr}")
		settingsUpdate["mqttAddr"] = data.inceptionAddr
		addressInfo = "Address Obtained: Settings: ${settingsUpdate}"
	} else {
		logWarn("getAddresses: Failure obtaining addresses.  Server returned an error.")
	}
	return addressInfo
}

def checkSessionStatus() {
	def sessionStatus = "notOpen"
	def uri = "https://life2.cloud.sengled.com/user/app/customer/isSessionTimeout.json"
	def body = [
		"uuid": "xxx",
		"osType": "android",
		"appCode": "life"
	]
	def headers = ["Cookie" : "JSESSIONID=${getDataValue("token")}"]
	def data = postJson(uri, headers, body)
	if (data.messageCode == "200" && data.info == "OK") {
		sessionStatus = "open"
	}
	return sessionStatus
}

//	===== Find/Add Device Methods =====
def addDevices() {
	logDebug("getDeviceData: Token status: ${getToken()}")
	def devices = getDevices()
	logDebug("getDeviceData: Devices = ${devices}")
	if (devices == "ERROR") {
		return "addDevices: ERROR getting device data"
	}
	def mssg = "addDevices: "
	devices.each{
		def attrData = it.attributeList
		def productCode = attrData.find { it.name == "productCode" }
		def dni = it.deviceUuid
		def isChild = getChildDevice(dni)
		if (!isChild && productCode.value == "wifielement") {
			//	=====	Parse Data for Device
			def attributes = attrData.find { it.name == "supportAttributes" }
			def type = "monoBulb"
			if (attributes.value.contains("color")) { type = "colorBulb" }
			def label = attrData.find { it.name == "name" }
			label = label.value
			def typeCodeData = attrData.find { it.name == "typeCode" }
			//	=====	Add Device
			try {
				addChildDevice("davegut", "Sengled Wifi ${type}", dni, [
					"label": label,
					"name":"Sengled Wifi ${type}",
					"attributes": "[${attributes.value}]"
				])
				mssg += "\n\t\tInstalled ${label},"
			} catch (error) {
				logWarn("Failed to install device. Device: ${device}, sensorId = ${it.id}.")
				logWarn(error)
				mssg += "\n\t\tFAILED TO INSTALL ${label},"
			}
		} else {
			mssg += "\n\t\t${label} already installed,"
		}
	}
	device.updateSetting("addDevices", [type:"bool", value: false])
	logInfo(mssg)
}

def getDevices() {
	def devices = "ERROR"
//	Check if appServerAddr works for the listing devices
//	def uri = "https://life2.cloud.sengled.com/life2/device/list.json"
	def uri = "${getDataValue("appServerAddr")}/device/list.json"
	def body = []
	def headers = ["Cookie" : "JSESSIONID=${getDataValue("token")}"]
	def data = postJson(uri, headers, body)
log.trace data
	if (data == "ERROR") {
		return data
	} else if (data.messageCode == "200" && data.info == "OK") {
		devices = data.deviceList
	}
	return devices
}
	   
def postJson(uri, headers, body) {
	def params = [
		uri: uri,
		headers: headers,
		body : new groovy.json.JsonBuilder(body).toString()
	]
	logDebug("postJson: ${params}")
logTrace("postJson: ${params}")
	def respData = "ERROR"
	try {
		httpPostJson(params) {resp ->
			if (resp.status == 200) {
				respData = resp.data
			} else {
				logWarn("postJson: SERVER ERROR.  Status = %{resp.status}")
			}
		}
	} catch(e) {
		logWarn("postJson: PROTOCOL ERROR: ${e}")
	}
	return respData
}

//	============== MQTT Comms
//	cmdData sent from child
def pubCmd(cmdData = state.cmdData) {
	logDebug("pubCmd: ${cmdData}")
	state.cmdData = cmdData
	runIn(3, handleCommsError)
	interfaces.mqtt.publish(cmdData.topic, cmdData.payload)
}

def retryCmd() {
	if (state.cmdData != "" && state.errorCount < 6) {
		pubCmd()
	}
}

//	Return message payload to child
def parse(message) {
	message = interfaces.mqtt.parseMessage(message)
	if (message.topic.contains("update")) { return }
	def payload = parseJson(message.payload)
log.trace message
	runIn(1, clearCommsError)
	def children = getChildDevices()
	children.each {
		if (message.topic == "wifielement/${it.device.deviceNetworkId}/status") {
//			it.parse(payload)
			it.buffReturn(payload)
		}
	}
}

def handleCommsError() {
	def count = state.errorCount + 1
	state.errorCount = count
	if (device.currentValue("commsError") == "false") {
		sendEvent(name: "commsError", value: true)
	}
	if(count > 5) {
		logWarn("handleCommsError: No retry.  Count = ${count}")
		if (!state.WARNING) {
			state.WARNING = "RETRYING ERRORS DISABLED"
		}
	}
	runIn(1, connect)
}

def clearCommsError() {
	unschedule(handleCommsError)
	state.errorCount = 0
	state.cmdData = ""
	if (state.WARNING) {
		state.remove("WARNING")
	}
	if (device.currentValue("commsError") == "true") {
		sendEvent(name: "commsError", value: false)
	}
}

//	=========================================
//	===== Connection Management Methods =====
//	=========================================
def mqttClientStatus(message) {
	logDebug("mqttClientStatus: ${message}")
	if(message == "Status: Connection succeeded" ||
	   message == "MqttException (0) - java.io.IOException: Already connected") {
		runInMillis(200, subscribeToTopics)
		sendEvent(name: "connected", value: "true")
	} else {
		def connected = isConnected()
		if (connected == "true") {
			disconnect()
		}
		connect()
	}
}

def subscribeToTopics() {
//	def subs = ["status", "update", "switch", "brightness","colorTemperature", "color", "effect", "colorMode"]
	def children = getChildDevices()
	children.each {
		def path = "wifielement/${it.deviceNetworkId}"
		interfaces.mqtt.subscribe("${path}/status")
		pauseExecution(50)
		interfaces.mqtt.subscribe("${path}/update")
		pauseExecution(50)
		logDebug("topicSubscribe: subscribed to ${path} status and update}")
	}
	//	=====	if error recovery, retry previous command
	retryCmd()
}

//	Basic MQTT Methods
def connect() {
	if (isConnected() == "true") { 
		logDebug("connect: disconnect from device.")
		def connected = disconnect()
		if(connected == "false") { connect() }
	} else {
		logDebug("connect: ${getDataValue("mqttAddr")} || ${getDataValue("token")}@lifeApp || ${userName}")
		interfaces.mqtt.connect(getDataValue("mqttAddr"),
								"${getDataValue("token")}@lifeApp",
								userName,
								userPwd
							   )
	}
}

def disconnect() {
	logDebug("disconnect")
	def connected = interfaces.mqtt.disconnect()
	return isConnected()
}

def isConnected() {
	def connected = interfaces.mqtt.isConnected().toString()
	if (connected != device.currentValue("connected")) {
		sendEvent(name: "connected", value: connected)
	}
	return connected
}

//	===== Preference Methods =====
def logTrace(msg){
	log.trace "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
}

def logInfo(msg) {
	if (descriptionText == true) { 
		log.info "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
	}
}

def logDebug(msg){
	if(debug == true) {
		log.debug "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
	}
}

def debugOff() {
	device.updateSetting("debug", [type:"bool", value: false])
	logInfo("debugLogOff: Debug logging is off.")
}

def logWarn(msg){
	log.warn "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
}

//	End of File
