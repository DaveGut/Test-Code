/*	Sengled Device Driver Series

		Copyright Dave Gutheinz

License Information:  https://github.com/DaveGut/HubitatActive/blob/master/sengledDevices/License.md

08.31.21	New release.  Provides for Color and Mono bulbs only.
===================================================================================================*/
def driverVer() { return "1.0.0" }
//def type() { return "monoBulb" }
def type() { return "colorBulb" }

metadata {
	definition (name: "Sengled Wifi ${type()}",
				namespace: "davegut",
				author: "Dave Gutheinz",
				importUrl: ""
			   ) {
		//	Device capabilities to be sent to child drivers
        capability "Bulb"
		capability "Light"
		capability "Switch"
		capability "Switch Level"
		capability "Actuator"
		if (type() == "colorBulb") {
			capability "Color Temperature"
			capability "Color Mode"
			capability "ColorControl"
			command "setEffect",  [[
				name: "Effect Name",
				constraints: ["none", "colorCycle", "randomColor", "rhythm",
							  "christmas", "halloween", "5 minutes",  "festival"],
				type: "ENUM"]]
			attribute "effect", "string"
		}
	}
	preferences {
		input ("debug", "bool",
			   title: "30 minutes of debug logging", 
			   defaultValue: true)
		input ("descriptionText", "bool", 
			   title: "Enable description text logging", 
			   defaultValue: true)
	}
}

def installed() {
	def message = "Installing device."
	updateDataValue("driverVersion", driverVer())
	state.NOTE = "Transition Time not supporte by this device."
	runIn(2, updated)
}

def updated() {
	logInfo("updated: Updating device preferences and settings.")
	def msg = "updated:"
	unschedule()

	if (debug) { runIn(1800, debugOff) }
	msg += "\n\tDebug Logging = ${debug}."
	msg += "\n\tDescription Text = ${descriptionText}."
	logInfo(msg)
	
	def payload = [
		"dn" : "${device.deviceNetworkId}",
		"time" : getTime()
		]
	payload = new groovy.json.JsonBuilder(payload)
	pubCmd(payload)
}

//	===============================
//	===== Bulb Unique Methods =====
//	===============================
def on() {
	logDebug("on")
	def payload = createPayload("switch", "1")
	pubCmd(payload)
}

def off() {
	logDebug("off")
	def payload = createPayload("switch", "0")
	pubCmd(payload)
}

def setEffect(effect) {
	logDebug("setEffect: ${effect}")
	def payload = createPayload(effect, "1")
	pubCmd(payload)
}

def setLevel(level, transTime = 0 ) {
	if (level < 0) { level = 0 }
	else if (level > 100) { level = 100 }
	if (device.currentValue("colorMode") == "RGB") {
		setColor([hue: device.currentValue("hue"),
				  saturation: device.currentValue("saturation"),
				  level: level])
		return
	}
	logDebug("setLevel: level = ${level}")
	def payload = createPayload("brightness", level)
	pubCmd(payload)
}

def setColorTemperature(colorTemp, level = device.currentValue("level"), transTime = 0) {
	logDebug("setColorTemperature: ${colorTemp} // ${level}")
	sendEvent(name: "colorMode", value: "CT")
	if (colorTemp < 2000) { colorTemp = 2000 }
	else if (colorTemp > 6500) { colorTemp = 6500 }
	def ctValue = ( (colorTemp - 2000) / 45 ).toInteger()
	if (level < 0) { level = 0 }
	else if (level > 100) { level = 100 }
	def element1 = createPayload("colorTemperature", ctValue)
	def element2 = createPayload("brightness", level)
	def payload = """[${element1},${element2}]"""
	pubCmd(payload)
}

def setHue(hue) {
	logDebug("setHue:  hue = ${hue}")
	setColor([hue: hue,
			  saturation: device.currentValue("saturation"),
			  level: device.currentValue("level")])
}

def setSaturation(saturation) {
	logDebug("setSaturation: saturation = ${saturation}")
	setColor([hue: device.currentValue("hue"),
			  saturation: saturation,
			  level: device.currentValue("level")])
}

def setColor(Map color) {
	logDebug("setColor:  ${color}")
	if (color == null) {
		LogWarn("setColor: Color map is null. Command not executed.")
		return
	}
	sendEvent(name: "colorMode", value: "RGB")
	def hue = color.hue.toInteger()
	if (hue == 0) { hue == 1 }
	def saturation = color.saturation.toInteger()
	if (saturation == 0) { saturation = hue }
	def level = color.level.toInteger()
	if (level == 0) { level = hue }
	if (hue < 0 || hue > 100 || saturation < 0 || saturation > 100 || level < 0 || level > 100) {
		logWarn("setColor: Entered hue, saturation, or level out of range! (H:${hue}, S:${saturation}, L:${level}")
        return
    }
//	Convert hsl to rgb
	def rgbData = hubitat.helper.ColorUtils.hsvToRGB([hue, saturation, level])
	def red = rgbData[0]
	def green = rgbData[1]
	def blue = rgbData[2]
	def payload = createPayload("color", "${red}:${green}:${blue}")
	pubCmd(payload)
}

//	Not currently referenced!
def refresh() {
	logDebug("refresh")
	def payload = [
		"dn" : "${device.deviceNetworkId}",
		"time" : getTime()
		]
	payload = new groovy.json.JsonBuilder(payload)
	pubCmd(payload)
}

//	Parse MQTT Reaponse
def buffReturn(payload) {
	if (state.parseBusy == true) {
		pauseExecution{500}
	}
	parse(payload)
}

def parse(payload) {
log.trace payload
	state.parseBusy = true
	def msg = "parse: ["
	payload.each {
		def type
		try { type = it.type } catch (e) { type = "nullValue" }
		def value = it.value
		if (value == null) { type = "nullValue" }
		switch (type) {
			case "nullValue":
				logWarn("parse: null value returned from device")
				break
			case "switch" :
				def onOff = "off"
				if (value == "1") { onOff = "on" }
				if (onOff != device.currentValue("switch")) {
					sendEvent(name: "switch", value: onOff)
				msg += "switch: ${onOff}, "
				}
				break
			case "colorMode":
				colorMode = "RGB"
				if (value == "2") { colorMode = "CT" }
				if (colorMode != device.currentValue("colorMode")) {
					sendEvent(name: "colorMode", value: colorMode)
					msg += "colorMode: ${colorMode}, "
				}
				break
			case "brightness":
				if (device.currentValue("colorMode") != "RGB") {
					def level = value.toInteger()
					if (level != device.currentValue("level")) {
						sendEvent(name: "level", value: level)
						msg += "level: ${level}, "
					}
				}
				break
			case "colorTemperature":
				if (device.currentValue("colorMode") != "CT") {
				def ctLevel = value.toInteger() * 45 + 2000
					if (ctLevel != device.currentValue("colorTemperature")) {
						def colorName = setColorTempName(ctLevel)
						sendEvent(name: "colorName", value: colorName)
						sendEvent(name: "colorTemperature", value: ctLevel)
						msg += "colorTemperature: ${ctLevel}, colorName: ${colorName}, "
					}
				}
				break
			case "color":
				if (device.currentValue("colorMode") == "RGB") {
					if (value != state.rgb) {
						state.rgb = value
						def rgbSplit = value.split(':')
						def red
						def green
						def blue
						def i = 0
						rgbSplit.each { part ->
							i = i + 1
							if (i == 1) { red = part.toInteger() }
							else if (i == 2) { green = part.toInteger() }
							else if (i == 3) { blue = part.toInteger() }
						}
						def hsvData = hubitat.helper.ColorUtils.rgbToHSV([red, green, blue])
						def hue = (0.5 + hsvData[0]).toInteger()
						def saturation = (0.5 + hsvData[1]).toInteger()
						def level = (0.5 + hsvData[2]).toInteger()
						def color = ["hue": hue, "saturation": saturation, "level": level]
						def colorName = setColorName(hue)
						sendEvent(name: "color", value: color)
						sendEvent(name: "hue", value: hue)
						sendEvent(name: "saturation", value: saturation)
						sendEvent(name: "level", value: level)
					    sendEvent(name: "colorName", value: colorName)
						msg += "color: ${color}, colorName: ${colorName}, "
					}
				}
				break
			case "effectStatus":
				def effect = "none"
				if (value == "1") { effect = "Color Cycle" }
				else if (value == "2") { effect = "Random Color" }
				else if (value == "3") { effect = "Rhythm" }
				else if (value == "4") { effect = "Christmas" }
				else if (value == "5") { effect = "Halloween" }
				else if (value == "6") { effect = "Festival" }
				if (effect != device.currentValue("effect")) {
					sendEvent(name: "effect", value: effect)
					msg += "effect: ${effect}, "
				}
				break
			case "deviceRssi":
				break
			default:
				logWarn("parse: Unhandled return: ${it}")
		}
	}
	if (msg != "parse: [") {
		msg += "]"
		logInfo(msg)
	}
	state.parseBusy = false
}

def setColorName(hue){
	def colorName
	hue = (3.6 * hue).toInteger()
	switch (hue){
		case 0..15: colorName = "Red"
            break
		case 16..45: colorName = "Orange"
            break
		case 46..75: colorName = "Yellow"
            break
		case 76..105: colorName = "Chartreuse"
            break
		case 106..135: colorName = "Green"
            break
		case 136..165: colorName = "Spring"
            break
		case 166..195: colorName = "Cyan"
            break
		case 196..225: colorName = "Azure"
            break
		case 226..255: colorName = "Blue"
            break
		case 256..285: colorName = "Violet"
            break
		case 286..315: colorName = "Magenta"
            break
		case 316..345: colorName = "Rose"
            break
		case 346..360: colorName = "Red"
            break
		default:
			logWarn("setRgbData: Unknown.")
			colorName = "Unknown"
    }
	return colorName
}

def setColorTempName(temp){
    def value = temp.toInteger()
    def colorName
	if (value <= 2800) { colorName = "Incandescent" }
	else if (value <= 3300) { colorName = "Soft White" }
	else if (value <= 3500) { colorName = "Warm White" }
	else if (value <= 4150) { colorName = "Moonlight" }
	else if (value <= 5000) { colorName = "Horizon" }
	else if (value <= 5500) { colorName = "Daylight" }
	else if (value <= 6000) { colorName = "Electronic" }
	else if (value <= 6500) { colorName = "Skylight" }
	else { colorName = "Polar" }
	return colorName
}

def getTime() {
	def time = new Date().getTime()
	return (time / 1000).toInteger()
}

def createPayload(type, value) {
	def payloadElement = [
		dn : device.deviceNetworkId,
		type : type,
		value : value.toString(),
		time : getTime()
		]
	return new groovy.json.JsonBuilder(payloadElement)
}

def pubCmd(payload) {
	logDebug("sendCmd: ${payload}")
	def topic = "wifielement/${device.deviceNetworkId}/update"
	parent.pubCmd([topic: "${topic}", payload: "${payload}"])
}

//	===== Preference Methods =====
def logTrace(msg){
	log.trace "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
}

def logInfo(msg) {
	if (descriptionText == true) { 
		log.info "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
	}
}

def logDebug(msg){
	if(debug == true) {
		log.debug "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
	}
}

def debugOff() {
	device.updateSetting("debug", [type:"bool", value: false])
	logInfo("debugLogOff: Debug logging is off.")
}

def logWarn(msg){
	log.warn "[${type()} / ${driverVer()} / ${device.label}]| ${msg}"
}

//	End of File
