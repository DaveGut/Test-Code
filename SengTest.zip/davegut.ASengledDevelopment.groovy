/*	SEngled Integration

		Copyright Dave Gutheinz

License Information:  https://github.com/DaveGut/HubitatActive/blob/master/sengledDevices/License.md

08.31.21	New release.  Provides for Color and Mono bulbs only.
===================================================================================================*/
def appVersion() { return "1.0.0" }
import groovy.json.JsonSlurper

definition(
	name: "A Sengled Development",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Application to install Sengled WiFi bulbs.",
	category: "Convenience",
	iconUrl: "",
	iconX2Url: "",
	singleInstance: true,
	documentationLink: "https://github.com/DaveGut/HubitatActive/blob/master/sengledDevices/Documentation.pdf",
	importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/sengledDevices/Application/sengledApp.groovy"
)

preferences {
	page(name: "startPage")
	page(name: "authenticationPage")
	page(name: "addDevicesPage")
	page(name: "getSengledData")
}

def installed() { initialize() }

def updated() { initialize() }

def initialize() {
	logInfo("initialize")
	unschedule()
	schedule("0 30 2 ? * WED", getToken)
}

def uninstalled() {
    getAllChildDevices().each { 
        deleteChildDevice(it.deviceNetworkId)
    }
}

def startPage() {
	initialize()
	logInfo("starting Sengled Integration, Version ${appVersion()}")
	if (selectedAddDevices) { addDevices() }
	if (!debugLog) { app.updateSetting("debugLog", false) }

	return dynamicPage(name:"startPage",
					   title:"<b>Sengled Local Hubitat Integration, Version ${appVersion()}</b>",
					   uninstall: true,
					   install: true) {
		section() {
			input "showInstructions", "bool",
				title: "<b>Page Hints</b>",
				submitOnChange: true,
				defaultalue: true
			if (showInstructions == true) {
				paragraph "<textarea rows=19 cols=66 readonly='true'>${stPgIns()}</textarea>"
			}

			href "authenticationPage",
				title: "<b>Sengled Login and Token Update</b>",
				description: "Go to Sengled Login Update."
			paragraph "\tSengled Token: ${sengledToken}\n\t" +
					  "appServerAddr: ${appServerAddr}\n\t" +
					  "mqttAddr: ${mqttAddr}\n\t" +
					  "SengledUserId: ${sengledUserId}\n"
			def msg = "After running Sengled Login and Token Update, refresh this page."
			paragraph msg

			href "addDevicesPage",
				title: "<b>Install Sengled Devices</b>",
				description: "Installs newly detected Sengled Device."

			input "debugLog", "bool", 
				title: "<b>Enable debug logging</b>", 
				submitOnChange: true,
				defaultValue: false
		}
	}
}

//	Get Sengled Cloud Credentials and Address Data
def authenticationPage() {
	logDebug("authenticationPage")
	return dynamicPage (name: "authenticationPage", 
    					title: "Initial Sengled Login Page, Version ${appVersion()}",
						nextPage: startPage,
                        install: false) {
		
        section("Enter Sengled Account Credentials: ") {
			input ("userName", "email", 
            		title: "Sengled Email Address", 
                    required: true, 
                    submitOnChange: true)
			
			input ("userPassword", "password", 
            		title: "Sengled Account Password", 
                    required: true, 
                    submitOnChange: true)
			
			if (userName && userPassword && userName != null && userPassword != null) {
				href "getSengledData", 
					title: "Get or Update Sengled Token and get addresses", 
					description: "Tap to Get Sengled Token"
            }
			paragraph "Select  '<'  at upper left corner to exit."
		}
	}
}

def getSengledData() {
	logInfo("getting Sengled token and addresses")
	def tokenInfo = getToken()
	logInfo("getSengledData: ${tokenInfo}")
	if (tokenInfo != "LOGIN ERROR") {
		def addressInfo = getAddresses()
		logInfo("getSengledData: ${addressInfo}")
	}
	return startPage()
}

//	Add Devices
def addDevicesPage() { 
	logInfo("addDevicesPage")
	def devices = getDeviceData()
	logDebug("addDevicesPage: ${devices}")
//log.trace devices
	state.devices = devices
	
	def uninstalledDevices = [:]
	def requiredDrivers = [:]
	devices.each {
		def isChild = getChildDevice(it.value.dni)
		if (!isChild) {
			uninstalledDevices["${it.value.dni}"] = "${it.value.alias} // ${it.value.type}"
			requiredDrivers["${it.value.type}"] = "sengled ${it.value.type}"
		}
	}
	def reqDrivers = "Ensure the following drivers are installed:"
	requiredDrivers.each {
		reqDrivers += "\n\t\t${it.value}"
	}
	reqDrivers += "</b>"
	def pageInstructions = "<b>Before Installing New Devices "
	pageInstructions += "${reqDrivers}\n"
	return dynamicPage(name:"addDevicesPage",
					   title: "Add Sengled Devices to Hubitat",
					   nextPage: startPage,
					   install: false) {
	 	section() {
			paragraph pageInstructions
			input ("selectedAddDevices", "enum",
				   required: false,
				   multiple: true,
				   title: "Devices to add (${uninstalledDevices.size() ?: 0} available)",
				   description: "Use the dropdown to select devices.  Then select 'Done'.",
				   options: uninstalledDevices)
		}
	}
}

def addDevices() {
	logInfo("addDevices: ${selectedAddDevices}")
	def hub = location.hubs[0]
	selectedAddDevices.each { dni ->
		def isChild = getChildDevice(dni)
		if (!isChild) {
			def device = state.devices.find { it.value.dni == dni }
			def deviceData = [:]
			deviceData["attributes"] = "[${device.value.attributes}]"
			deviceData["typeCode"] = device.value.typeCode
			try {
				addChildDevice(
					"davegut",
					"Sengled Wifi ${device.value.type}",
					device.value.dni,
					hub.id, [
						"label": device.value.alias,
						"data" : deviceData
					]
				)
				logInfo("Installed ${device.value.alias}.")
			} catch (error) {
				logWarn("Failed to install device." + 
						"\n<b>Data: ${device}</b>" + 
						"\n${error}")
			}
		}
		pauseExecution(3000)
	}
	app?.removeSetting("selectedAddDevices")
}

def getDeviceData() {
	logInfo("getDeviceData: Token status: ${getToken()}")
	def deviceList = getDevices()
	logDebug("getDeviceData: Devices = ${deviceList}")
	def devices = [:]
	deviceList.each{
		def attrData = it.attributeList
		def productCode = attrData.find { it.name == "productCode" }
		if (productCode.value == "wifielement") {
			def device = [:]
//			device["deviceUuid"] = it.deviceUuid
			def dni = it.deviceUuid
			device["dni"] = dni
			def nameData = attrData.find { it.name == "name" }
			device["alias"] = nameData.value
			def attributes = attrData.find { it.name == "supportAttributes" }
			device["attributes"] = attributes.value
			def type = "monoBulb"
			if (attributes.value.contains("color")) { type = "colorBulb" }
			device["type"] = type
			def typeCodeData = attrData.find { it.name == "typeCode" }
			device["typeCode"] = typeCodeData.value
			def onLineData = attrData.find { it.name == "online" }
			device["onLine"] = onLineData.value
			devices << ["${dni}" : device]
			logDebug("updateDevices: ${type} ${nameData.value} added to devices array.")
		}
	}
	return devices
}

////////////////////////////////////////////
def updateChildren() {
	logDebug("updateChildren:  DISABLED")
return
	
	def devices = state.devices
	devices.each {
		def child = getChildDevice(it.key)
		if (child) {
			child.debugOff()
			child.updateDataValue("type", it.value.type)
			child.updateDataValue("feature", it.value.feature)
			child.updateDataValue("deviceId", it.value.deviceId)
			if (it.value.ip != null || it.value.ip != "") {
				child.updateDataValue("deviceIP", it.value.ip)
			}
			def childVer = child.driverVer().substring(0,3).toString()
			def appVer = appVersion().substring(0,3).toString()
			if (childVer != appVer) {
				logWarn("<b>updateDevices:  Child Driver is not up to date. Device = ${it.value.alias}!</b>")
			}
			child.updated()
		}
	}
}

//	Update CLOUD Token
def fixConnection(type) {
	logInfo("fixData: Update ${type} data")
	def message = ""
	if (pollEnable == false) {
		message += "Unable to update data.  Updated in last 15 minutes."
		return
	} else {
		runIn(900, pollEnable)
		app?.updateSetting("pollEnabled", [type:"bool", value: false])
	}
	message += "Getting new token.  Value = ${getToken()}."
	return message
}

def pollEnable() {
	logInfo("pollEnable: polling capability enabled.")
	app?.updateSetting("pollEnabled", [type:"bool", value: true])
}

//	Cloud Commands and Communications
def getToken() {
	def uri = "https://life2.cloud.sengled.com/user/app/customer/v2/AuthenCross.json"
	def body = ["uuid": "xxx", "user": userName, "pwd": userPassword,
				"osType": "android", "productCode": "life", "appCode": "life"]
	def headers = ["Content-Type": "application/json"]
	def data = postJson(uri, headers, body)
//log.trace "getToken data: $data"
	if (data.ret == 0) {
		def settingsUpdate = [:]
		app?.updateSetting("sengledToken", data.jsessionId)
		sengledToken = data.jsessionId
		settingsUpdate["sengledToken"] = sengledToken
		app?.updateSetting("sengledUserId", data.customerId)
		settingsUpdate["sengledUserId"] = data.customerId
		tokenInfo = "Login Success: ${settingsUpdate}"
	} else {
		logWarn("getToken: Login Failure.  Server returned an error.")
	}
	return tokenInfo
}

def getAddresses() {
	def addressInfo = "ADDRESS DATA ERROR"
	def uri = "https://life2.cloud.sengled.com/life2/server/getServerInfo.json"
	def body = []
	def headers = ["Cookie" : "JSESSIONID=${sengledToken}"]

	def data = postJson(uri, headers, body)
	if (data.messageCode == "200") {
		def settingsUpdate = [:]
		app?.updateSetting("appServerAddr", data.appServerAddr)
		settingsUpdate["appServerAddr"] = data.appServerAddr
		app?.updateSetting("mqttAddr", data.inceptionAddr)
		settingsUpdate["mqttAddr"] = data.inceptionAddr
		addressInfo = "Address Obtained: ${settingsUpdate}"
	} else {
		logWarn("getAddresses: Failure obtaining addresses.  Server returned an error.")
	}
	return addressInfo
}

def checkSessionStatus() {
	def sessionStatus = "notOpen"
	def uri = "https://life2.cloud.sengled.com/user/app/customer/isSessionTimeout.json"
	def body = [
		"uuid": "xxx",
		"osType": "android",
		"appCode": "life"
	]
	
	def headers = ["Cookie" : "JSESSIONID=${sengledToken}"]
	def data = postJson(uri, headers, body)
//log.trace "checkSessionStatus data: $data"
	if (data.messageCode == "200" && data.info == "OK") {
		sessionStatus = "open"
	}
	return sessionStatus
}

def getDevices() {
	logInfo("getDevices")
	def devices = "ERROR"
	def uri = "https://life2.cloud.sengled.com/life2/device/list.json"
	def body = []
	def headers = ["Cookie" : "JSESSIONID=${sengledToken}"]
	def data = postJson(uri, headers, body)
//log.trace data
	if (data.messageCode == "200" && data.info == "OK") {
		devices = data.deviceList
	}
	return devices
}
	   
def postJson(uri, headers, body) {
	def params = [
		uri: uri,
		headers: headers,
		body : new groovy.json.JsonBuilder(body).toString()
	]
	logDebug("postJson: ${params}")
//logInfo("postJson: ${params}")

	def respData = "ERROR"
	try {
		httpPostJson(params) {resp ->
			if (resp.status == 200) {
				respData = resp.data
			} else {
				logWarn("postJson: SERVER ERROR.  Status = %{resp.status}")
			}
		}
	} catch(e) {
		logWarn("postJson: PROTOCOL ERROR: ${e}")
	}
	return respData
}

//	Utility Methods
def logTrace(msg){ log.trace "[SengledInt/${appVersion()}] ${device.label} ${msg}" }

def logInfo(msg){ log.info "[SengledInt/${appVersion()}]: ${msg}" }

def logDebug(msg){
	if (debug){
		log.debug "[SengledInt/${appVersion()}]: ${msg}" }
}

def logWarn(msg) { log.warn "[SengledInt/${appVersion()}]: ${msg}" }

//	Page Instructions
def stPgIns() {
	def startPgIns = "Use Alternate Lan Segment: Use if you use a different LAN segment for your devices that your Hub.  Usually false."
	startPgIns += "\n\nAlternate Lan Segment: Displayed whte Use Alternate Lan Segment is true.  Enter alternate segment."
	startPgIns += "\n\nInterface to Sengled Cloud: Select if you want to use the Sengled Cloud for some devices.  "
	startPgIns += "Device must be bound to the Sengled Cloud. If not selected, Sengled Cloud will not be accessed even if previously active."
	startPgIns += "\n\nSengled Login and Token Update: Displayed whe Interface to Sengled Cloud is true.  Access Sengled Login page."
	startPgIns += "\n\nInstall Sengled Devices / Update Installed Devices: Searches for Sengled Devices and allows selection for adding to Hubitat Hub.  "
	startPgIns += "Also updated data and Saves Preferences on installed devices, i.e., after updating the app/driver versions."
	startPgIns += "\n\nRemove Sengled Devices: Searches for installed devices and allows removal of those devices."
	return startPgIns
}

//	end-of-file